export default function ActualizarOrden (){
    return(
        <h1>Actualizar orden</h1>
    );

};